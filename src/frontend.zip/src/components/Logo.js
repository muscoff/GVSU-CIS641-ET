import React from 'react'
import logo from '../shop_image.png'

export default function Logo() {
  return (
    <div>
        <img src={logo} className="img" />
    </div>
  )
}
