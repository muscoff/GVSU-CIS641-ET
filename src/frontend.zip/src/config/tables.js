export default {
    adminlogintable: 'et_adminlogin',
    userlogintable: 'et_userlogin',
    userstable: 'et_users',
    producttable: 'et_product',
    cart: 'et_cart',
}